import { useState, useEffect } from 'react';
import { SettingsContext } from './useContexts';

/**
 * Fetches /shelf-runner/v1/settings once to collect user or PHP-provided constants and settings.
 * 
 * @param {Object} props
 * @param {React.ReactNode} props.children The children to render
 * @returns {React.ReactNode} The SettingsContextProvider component
 */
export function SettingsContextProvider({ children }) {
  const [settings, setSettings] = useState({});
  const [jump, setJump] = useState({ height: 0, hangtime: 0 });
  const [makeMusic, setMakeMusic] = useState(false);
  const [makeSFX, setMakeSFX] = useState(false);
  const [levelPhysics, setLevelPhysics] = useState({speed: 1, jump: 1, hangtime: 1});

  useEffect(() => {
    fetch(`${window.sr.api}shelf-runner/v1/settings`)
      .then(response => response.json())
      .then(d => {
        setSettings(d.data);
        setJump({
          height: (d.data.jumpHeight), // Percentage like 0 - 1.
          hangtime: d.data.jumpHangtime // In seconds.
        });
      })
      .catch(error => {
        console.error('Failed to fetch settings:', error);
      });
  }, []);

  const value = { settings, setSettings, jump, setJump, makeMusic, setMakeMusic, makeSFX, setMakeSFX, levelPhysics, setLevelPhysics };

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
}
