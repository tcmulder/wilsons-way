/**
 * Show current version information
 */

export const Version = () => {
	return (
		<span className="sr-version">v2.0.4</span>
	);
};