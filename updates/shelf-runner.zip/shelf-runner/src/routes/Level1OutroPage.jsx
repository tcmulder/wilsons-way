const Level1OutroPage = () => {
	return (
		<div>
			<h1>You've completed Level 1!</h1>
		</div>
	);
};

export default Level1OutroPage;