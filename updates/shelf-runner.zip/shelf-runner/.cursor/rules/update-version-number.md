# Task: Update Version Number

Whenever I say "update the version number", do the following:

- Increment the patch number of `Version:` in shelf-runner.php (or use a different version number if I specified something specific).
- Update the version to match in readme.txt's "Stable tag:", shelf-runner.php's "SHELF_RUNNER_VERSION", Version.jsx's "sr-version" , and info.json's "version".
- Add a very brief description of the latest changes to readme.txt's changelog with the new version number header.